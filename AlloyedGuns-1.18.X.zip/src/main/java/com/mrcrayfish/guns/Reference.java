package com.mrcrayfish.guns;

public class Reference
{
	public static final String MOD_ID = "alloyedguns";
}
