package com.mrcrayfish.guns.client.settings;

import net.minecraft.client.Options;
import net.minecraft.client.gui.components.SliderButton;
import net.minecraft.client.ProgressOption;

/**
 * Author: MrCrayfish
 */
public class GunOptionSlider// extends SliderButton
{
    /*private final ProgressOption option;

    public GunOptionSlider(Options settings, int x, int y, int width, int height, ProgressOption option)
    {
        super(settings, x, y, width, height, option, );
        this.option = option;
    }

    @Override
    protected void applyValue()
    {
        this.option.set(this.options, this.option.toValue(this.value));
    }*/
}
