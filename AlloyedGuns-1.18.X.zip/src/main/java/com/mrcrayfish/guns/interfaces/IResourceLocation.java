package com.mrcrayfish.guns.interfaces;

import net.minecraft.resources.ResourceLocation;

/**
 * Author: MrCrayfish
 */
public interface IResourceLocation
{
    ResourceLocation getLocation();
}
