package com.mrcrayfish.guns.item;

/**
 * A simple interface to indicate that this item is ammo. This will make sure that it's put into the
 * correct category in the workbench.
 *
 * Author: MrCrayfish
 */
public interface IAmmo
{
}
